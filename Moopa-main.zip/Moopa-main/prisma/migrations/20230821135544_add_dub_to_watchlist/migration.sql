-- AlterTable
ALTER TABLE "WatchListEpisode" ADD COLUMN     "dub" BOOLEAN;
