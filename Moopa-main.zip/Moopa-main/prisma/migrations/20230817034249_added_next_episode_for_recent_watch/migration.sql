-- AlterTable
ALTER TABLE "WatchListEpisode" ADD COLUMN     "nextId" TEXT,
ADD COLUMN     "nextNumber" INTEGER;
