# Changelog

This pre-release update is intended exclusively for our GitHub repository code. When we mark a release as "pre-release," it signifies that our website is up-to-date with this pre-release code. However, please note that this code is not yet officially released to the public.

## 🎉 Update pre-v4.3.0

## What's Changed

- Added changelogs section
- Added recommendations based on user lists (must be logged in)
- New Player!
  - Double tap to seek
  - Preview thumbnail (only zoro providers support this atm)
- Removed 9anime provider
- Fixed missing episodes thumbnail
- Fixed manga search and getting manga using anilist id
- And other minor bug fixes!
