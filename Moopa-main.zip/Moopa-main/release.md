# Changelog

This document contains a summary of all significant changes made to this release.

## 🎉 Update v4.2.5

### What's Changed

- fix: Gogoanime episode id is null
